-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2019 at 12:11 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webcam`
--

-- --------------------------------------------------------

--
-- Table structure for table `snapshot`
--

CREATE TABLE `snapshot` (
  `Id` int(11) NOT NULL,
  `Image` varchar(20000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `snapshot`
--

INSERT INTO `snapshot` (`Id`, `Image`) VALUES
(20, 'webcamImage/20190525063147.jpg'),
(21, 'webcamImage/20190525063529.jpg'),
(22, 'webcamImage/20190525063609.jpg'),
(23, 'webcamImage/20190525063710.jpg'),
(24, 'webcamImage/20190525064115.jpg'),
(25, 'webcamImage/20190525064131.jpg'),
(26, 'webcamImage/20190525064341.jpg'),
(27, 'webcamImage/20190525064355.jpg'),
(28, 'webcamImage/20190525064526.jpg'),
(29, 'webcamImage/20190525064601.jpg'),
(30, 'webcamImage/20190525064620.jpg'),
(31, 'webcamImage/20190525064655.jpg'),
(32, 'webcamImage/20190525064707.jpg'),
(33, 'webcamImage/20190525070431.jpg'),
(34, 'webcamImage/20190525070542.jpg'),
(35, 'webcamImage/20190525070618.jpg'),
(36, 'webcamImage/20190525070636.jpg'),
(37, 'webcamImage/20190525070706.jpg'),
(38, 'webcamImage/20190525070736.jpg'),
(39, 'webcamImage/20190525070755.jpg'),
(40, 'webcamImage/20190525073120.jpg'),
(41, 'webcamImage/20190525074821.jpg'),
(42, 'webcamImage/20190525074858.jpg'),
(43, 'webcamImage/20190525080532.jpg'),
(44, 'webcamImage/20190525080612.jpg'),
(45, 'webcamImage/20190525080732.jpg'),
(46, 'webcamImage/20190525080805.jpg'),
(47, 'webcamImage/20190525080847.jpg'),
(48, 'webcamImage/20190525121020.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `snapshot`
--
ALTER TABLE `snapshot`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `snapshot`
--
ALTER TABLE `snapshot`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
