<?php

require "FaceDetector.php";
use svay\FaceDetector;

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webcam";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else{

$sql="SELECT * from snapshot ORDER BY id DESC LIMIT 1";
$res=$conn->query($sql);

while($row = mysqli_fetch_array($res))
  {
  	$img=$row['Image'];
	$faceDetect = new FaceDetector();
	$faceDetect->faceDetect($img);
	$faceDetect->toJpeg();

  }



}




